data:extend(
{
    {
        type = "recipe-category",
        name = "aractgy-portable-generators"
    }
}
)